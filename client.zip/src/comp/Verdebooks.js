import React from 'react';

function Verdebooks() {
    return <iframe src="https://verdebooks.com/#/landing" style={{ width: "100%", height: "100vh", overflow: "hidden", border: "none", padding:'100px 30px' }} />;
}

export default Verdebooks;